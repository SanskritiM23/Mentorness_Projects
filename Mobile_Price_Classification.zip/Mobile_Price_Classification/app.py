import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib

# Load the trained model
model = joblib.load("trained_model.pkl")  # Make sure to replace "trained_model.pkl" with the filename of your trained model

# Define function for preprocessing input data
def preprocess_input_data(input_data):
    # Feature scaling
    scaler = StandardScaler()
    input_data_scaled = scaler.fit_transform(input_data)
    return input_data_scaled

# Create the UI
def main():
    st.title("Mobile Price Range Prediction")

    # Sidebar for user input
    st.sidebar.title("User Input")

    # Input fields for features
    battery_power = st.sidebar.slider("Battery Power (mAh)", 500, 7000, 2000)
    blue = st.sidebar.selectbox("Bluetooth", [0, 1])
    clock_speed = st.sidebar.slider("Clock Speed", 0.0, 3.0, 1.0)
    dual_sim = st.sidebar.selectbox("Dual SIM", [0, 1])
    fc = st.sidebar.slider("Front Camera (MP)", 0, 20, 5)
    four_g = st.sidebar.selectbox("4G Support", [0, 1])
    int_memory = st.sidebar.slider("Internal Memory (GB)", 0, 256, 64)
    m_dep = st.sidebar.slider("Mobile Depth (cm)", 0.0, 1.0, 0.5)
    mobile_wt = st.sidebar.slider("Mobile Weight", 80, 200, 150)
    n_cores = st.sidebar.slider("Number of Cores", 1, 8, 4)
    pc = st.sidebar.slider("Primary Camera (MP)", 0, 30, 10)
    px_height = st.sidebar.slider("Pixel Resolution Height", 0, 2000, 1000)
    px_width = st.sidebar.slider("Pixel Resolution Width", 0, 2000, 1000)
    ram = st.sidebar.slider("RAM (MB)", 256, 8192, 2048)
    sc_h = st.sidebar.slider("Screen Height (cm)", 5, 20, 10)
    sc_w = st.sidebar.slider("Screen Width (cm)", 5, 20, 10)
    talk_time = st.sidebar.slider("Talk Time", 2, 24, 12)
    three_g = st.sidebar.selectbox("3G Support", [0, 1])
    touch_screen = st.sidebar.selectbox("Touch Screen", [0, 1])
    wifi = st.sidebar.selectbox("WiFi", [0, 1])

    # Create DataFrame from user input
    user_input = pd.DataFrame({
        "battery_power": [battery_power],
        "blue": [blue],
        "clock_speed": [clock_speed],
        "dual_sim": [dual_sim],
        "fc": [fc],
        "four_g": [four_g],
        "int_memory": [int_memory],
        "m_dep": [m_dep],
        "mobile_wt": [mobile_wt],
        "n_cores": [n_cores],
        "pc": [pc],
        "px_height": [px_height],
        "px_width": [px_width],
        "ram": [ram],
        "sc_h": [sc_h],
        "sc_w": [sc_w],
        "talk_time": [talk_time],
        "three_g": [three_g],
        "touch_screen": [touch_screen],
        "wifi": [wifi]
    })

    # Preprocess user input
    user_input_processed = preprocess_input_data(user_input)

    # Make predictions
    prediction = model.predict(user_input_processed)

    # Display prediction
    st.subheader("Prediction")
    price_range_mapping = {0: "Low Cost", 1: "Medium Cost", 2: "High Cost", 3: "Very High Cost"}
    prediction_label = price_range_mapping[prediction[0]]
    st.write("Predicted Price Range:", prediction_label)

if __name__ == "__main__":
    main()
